﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MessageBroker
{
    // -----------------------------------------------------------------------------
    // Why is this class so simple?
    //
    // You may see examples online that use private constructors, factory methods,
    // validation, helper functions, and enough design patterns to make a software
    // architect very happy. There is certainly a place for those techniques. This
    // absolutely isn't one of them.
    //
    // The Message Broker is simply moving data from one part of the application to
    // another. The message key defines the contract between the sender and the
    // receiver. If you subscribe to "NAX.Zone.Volume", you should already know
    // that the Analog value contains the volume. If you don't know what a message
    // contains, no amount of factory methods is going to save you.
    //
    // Could we add helper methods to prevent someone from creating an "invalid"
    // message? Sure. We could also wrap every integer in its own class, but at some
    // point we stop solving real problems and start writing code to protect the
    // programmer from... the programmer. Or worse to impress someone on 
    // stack overflow or reddit. Those people do not matter. Their opinions
    // do not matter.   
    //
    // Good software is not measured by how many classes or helper methods it has.
    // It is measured by how easy it is to understand and maintain. Keeping this
    // class simple makes it easier to read, easier to debug, and easier to learn.
    //
    // Remember: Every line of code you write is another line you have to maintain.
    // Don't add complexity unless it buys you something worthwhile. 
    // -----------------------------------------------------------------------------

    // I am setting all of these in the class so they are clearly not nullable.
    // technically the digital and analog do not need this, but deterministic coding 
    // leaves no doubt to any other programmer that looks at it later.
    // And yes I used Digital, Analog, Serial on purpose.  But this object can be more
    // complex to convey more information.  You are free to modify how this works for 
    // your own uses.

    // Lets put it this way,  Message broker is all I use anymore, I really hate the
    // passing of objects hell that can cause context problems with traditional
    // ways of setting things up. and it can easily be expanded to send messages
    // beyond this program and to other programs.
    public class Message
    {
        public bool Digital { get; set; } = false;
        public ushort Analog { get; set; } = 0;
        public string Serial { get; set; } = ""; 
    }
}

